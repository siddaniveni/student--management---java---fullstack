package com.example.student.service;

import com.example.student.dao.StudentDAO;
import com.example.student.model.Student;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    private final StudentDAO studentDAO;

    public StudentService(StudentDAO studentDAO) {
        this.studentDAO = studentDAO;
    }

    public List<Student> getStudents() {
        return studentDAO.getAllStudents();
    }

    public void addStudent(Student student) {
        validate(student);
        studentDAO.addStudent(student);
    }

    public boolean updateStudent(int id, Student student) {
        validate(student);
        return studentDAO.updateStudent(id, student) > 0;
    }

    public boolean deleteStudent(int id) {
        return studentDAO.deleteStudent(id) > 0;
    }

    private void validate(Student student) {
        if (student.getName() == null || student.getName().isBlank()) {
            throw new IllegalArgumentException("Name is required");
        }
        if (student.getEmail() == null || student.getEmail().isBlank()) {
            throw new IllegalArgumentException("Email is required");
        }
        if (student.getCourse() == null || student.getCourse().isBlank()) {
            throw new IllegalArgumentException("Course is required");
        }
        if (student.getMarks() < 0 || student.getMarks() > 100) {
            throw new IllegalArgumentException("Marks must be between 0 and 100");
        }
    }
}

package com.example.student.dao;

import com.example.student.model.Student;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class StudentDAO {

    private final JdbcTemplate jdbcTemplate;

    public StudentDAO(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Student> getAllStudents() {
        String sql = "SELECT * FROM students ORDER BY id DESC";

        return jdbcTemplate.query(sql, (rs, rowNum) ->
            new Student(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("course"),
                rs.getInt("marks")
            )
        );
    }

    public int addStudent(Student student) {
        String sql = "INSERT INTO students(name,email,course,marks) VALUES(?,?,?,?)";

        return jdbcTemplate.update(
            sql,
            student.getName(),
            student.getEmail(),
            student.getCourse(),
            student.getMarks()
        );
    }

    public int updateStudent(int id, Student student) {
        String sql = "UPDATE students SET name=?, email=?, course=?, marks=? WHERE id=?";

        return jdbcTemplate.update(
            sql,
            student.getName(),
            student.getEmail(),
            student.getCourse(),
            student.getMarks(),
            id
        );
    }

    public int deleteStudent(int id) {
        String sql = "DELETE FROM students WHERE id=?";
        return jdbcTemplate.update(sql, id);
    }
}

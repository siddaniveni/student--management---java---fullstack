const API = "/api/students";

async function loadStudents() {
    try {
        const response = await fetch(API);

        if (!response.ok) {
            throw new Error("Could not load students");
        }

        const students = await response.json();
        const table = document.getElementById("studentTable");

        table.innerHTML = "";

        students.forEach(student => {
            const row = document.createElement("tr");

            row.innerHTML = `
                <td>${student.id}</td>
                <td>${escapeHtml(student.name)}</td>
                <td>${escapeHtml(student.email)}</td>
                <td>${escapeHtml(student.course)}</td>
                <td>${student.marks}</td>
                <td>
                    <button class="edit"
                        onclick='editStudent(${JSON.stringify(student)})'>
                        Edit
                    </button>
                    <button class="delete"
                        onclick="deleteStudent(${student.id})">
                        Delete
                    </button>
                </td>
            `;

            table.appendChild(row);
        });
    } catch (error) {
        showMessage(error.message, true);
    }
}

async function saveStudent() {
    const id = document.getElementById("studentId").value;

    const student = {
        name: document.getElementById("name").value.trim(),
        email: document.getElementById("email").value.trim(),
        course: document.getElementById("course").value.trim(),
        marks: Number(document.getElementById("marks").value)
    };

    if (!student.name || !student.email || !student.course ||
        Number.isNaN(student.marks)) {
        showMessage("Please fill all fields", true);
        return;
    }

    try {
        const response = await fetch(
            id ? `${API}/${id}` : API,
            {
                method: id ? "PUT" : "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(student)
            }
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "Request failed");
        }

        showMessage(data.message, false);
        clearForm();
        await loadStudents();
    } catch (error) {
        showMessage(error.message, true);
    }
}

function editStudent(student) {
    document.getElementById("studentId").value = student.id;
    document.getElementById("name").value = student.name;
    document.getElementById("email").value = student.email;
    document.getElementById("course").value = student.course;
    document.getElementById("marks").value = student.marks;

    document.getElementById("formTitle").textContent = "Update Student";
    window.scrollTo({ top: 0, behavior: "smooth" });
}

async function deleteStudent(id) {
    if (!confirm("Delete this student?")) {
        return;
    }

    try {
        const response = await fetch(`${API}/${id}`, {
            method: "DELETE"
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "Delete failed");
        }

        showMessage(data.message, false);
        await loadStudents();
    } catch (error) {
        showMessage(error.message, true);
    }
}

function clearForm() {
    document.getElementById("studentId").value = "";
    document.getElementById("name").value = "";
    document.getElementById("email").value = "";
    document.getElementById("course").value = "";
    document.getElementById("marks").value = "";
    document.getElementById("formTitle").textContent = "Add Student";
}

function showMessage(message, error) {
    const element = document.getElementById("message");
    element.textContent = message;
    element.style.color = error ? "#dc2626" : "#16a34a";
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

loadStudents();

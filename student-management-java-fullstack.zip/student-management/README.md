# Student Management System - Java Full Stack

A beginner-friendly full-stack application using:

- Java 17
- Spring Boot
- Spring Web / REST API
- Spring JDBC
- MySQL
- HTML
- CSS
- JavaScript
- Maven

MongoDB dependency is included for future activity-log functionality, but the current working CRUD application uses MySQL + JDBC.

## 1. Requirements

Install:

1. JDK 17 or later
2. Maven
3. MySQL
4. IntelliJ IDEA / Eclipse / VS Code (optional)

## 2. Create the database

Open MySQL Workbench and run the contents of `database.sql`.

## 3. Configure MySQL password

Open:

`src/main/resources/application.properties`

Change:

`spring.datasource.password=YOUR_MYSQL_PASSWORD`

to your actual MySQL password.

## 4. Run the application

From the project folder:

```bash
mvn spring-boot:run
```

Or open the project in IntelliJ/Eclipse and run:

`StudentApplication.java`

## 5. Open the application

Open:

http://localhost:8080/

The frontend is served directly by Spring Boot.

## 6. REST endpoints

GET all students:

`GET http://localhost:8080/api/students`

POST a student:

`POST http://localhost:8080/api/students`

Example JSON:

```json
{
  "name": "Anu",
  "email": "anu@gmail.com",
  "course": "B.Tech CSE",
  "marks": 90
}
```

PUT/update:

`PUT http://localhost:8080/api/students/1`

DELETE:

`DELETE http://localhost:8080/api/students/1`

## 7. Architecture

Frontend
→ REST Controller
→ Service
→ DAO
→ Spring JDBC
→ MySQL

## 8. Interview explanation

"I developed a Student Management System using Java and Spring Boot. I created REST APIs using Spring Web, implemented business logic in a service layer, and used Spring JDBC/JDBC for MySQL database operations. The frontend uses HTML, CSS and JavaScript and communicates with the backend through REST APIs."

## 9. Important note

This is a learning/project version. For production, add authentication, authorization, stronger validation, centralized exception handling, database migrations, logging, tests, and secure secret management.

CREATE DATABASE IF NOT EXISTS studentdb;
USE studentdb;

CREATE TABLE IF NOT EXISTS students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    course VARCHAR(100) NOT NULL,
    marks INT NOT NULL
);

INSERT INTO students(name, email, course, marks)
VALUES
('Veni', 'veni@gmail.com', 'B.Tech CSE', 85),
('Ravi', 'ravi@gmail.com', 'B.Tech CSE', 78);
